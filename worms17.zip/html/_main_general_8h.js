var _main_general_8h =
[
    [ "COMMENT_AUTHORS", "_main_general_8h.html#af93d8f0caba1069226df73ae364284b2", null ],
    [ "COMMENT_BW_ICON", "_main_general_8h.html#a429a338b5a47bd9cd8948d9df5fc2bd7", null ],
    [ "COMMENT_GRAY_ICON", "_main_general_8h.html#a2ed5932f86792ef5f29918b506fe87cc", null ],
    [ "COMMENT_PROGRAM_NAME", "_main_general_8h.html#a08e2666002361d5f437b03f0ddc13dd9", null ],
    [ "COMMENT_STRING", "_main_general_8h.html#aea7db5c65fc41f20ef5e5db86fee9ad7", null ],
    [ "COMMENT_VERSION_NUMBER", "_main_general_8h.html#a071935ec169f3dcbd28d7d9b9994b77e", null ],
    [ "COMMENT_VERSION_STRING", "_main_general_8h.html#a70b733d8c5b04a2fcc054e019d02e80a", null ]
];