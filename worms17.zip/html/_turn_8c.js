var _turn_8c =
[
    [ "Turn_enter", "_turn_8c.html#a7f7c98ae7ce5b547b375ee89a22606ff", null ],
    [ "Turn_exit", "_turn_8c.html#ad061d83747138e131103601179b0d01d", null ],
    [ "Turn_update", "_turn_8c.html#aff7a1d641108039085e6fae6b0d08f52", null ]
];