var _death_8c =
[
    [ "Death_enter", "_death_8c.html#a4958a881e720c69b02bc3516f3f96583", null ],
    [ "Death_exit", "_death_8c.html#aca2e6b6ed042410c23d379e6b110c3dc", null ],
    [ "Death_update", "_death_8c.html#acec6ba08457b4372faad9f20a99892e8", null ]
];