var _turn_end_8c =
[
    [ "TurnEnd_enter", "_turn_end_8c.html#ae16b5032613ab0e2a6b52f835e70307a", null ],
    [ "TurnEnd_exit", "_turn_end_8c.html#a4fcd45d23092c5cc2d32f88248c2d426", null ],
    [ "TurnEnd_update", "_turn_end_8c.html#ad9ed22f71d39607ccde114264820d17c", null ]
];