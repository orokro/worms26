var _crates_8c =
[
    [ "checkExplosions", "_crates_8c.html#a666d1827597498a7c6d09613f02ead6e", null ],
    [ "Crates_spawnCrate", "_crates_8c.html#af1f0877a91de9767e8d49bef5e7bbcd5", null ],
    [ "Crates_update", "_crates_8c.html#a384991346da52c456de16298545aac75", null ],
    [ "spawnCrate", "_crates_8c.html#ac1aa3b3ae8276441b9243f914c414ca2", null ],
    [ "Crate_active", "_crates_8c.html#a5229139895aec628e9cc8a7187f13cd7", null ],
    [ "Crate_health", "_crates_8c.html#a2d322dfea0620841b1c39572e96d43c6", null ],
    [ "Crate_type", "_crates_8c.html#af8057702b429447344c8240dbd027408", null ],
    [ "Crate_x", "_crates_8c.html#a6c660112989597df8f16f9a2a2dc02dd", null ],
    [ "Crate_y", "_crates_8c.html#a8dff93bf23c85968a2de6a4d61a03df1", null ]
];