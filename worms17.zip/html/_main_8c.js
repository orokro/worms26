var _main_8c =
[
    [ "_main", "_main_8c.html#abaa8f446abb569a6f850a328569bec9f", null ],
    [ "dist", "_main_8c.html#ac8b6486e40121e70781460e18c306377", null ],
    [ "GblDBuffer", "_main_8c.html#a0da9baf7116973a8c8c313b755280738", null ],
    [ "mapBuffer", "_main_8c.html#aeb0f05ac7690cc5a119602a1a4541e1e", null ]
];