var struct_t_t_a_r_c_h_i_v_e___h_e_a_d_e_r =
[
    [ "entry", "struct_t_t_a_r_c_h_i_v_e___h_e_a_d_e_r.html#a26beff89adf8b8846be671843796d464", null ],
    [ "magic", "struct_t_t_a_r_c_h_i_v_e___h_e_a_d_e_r.html#a3401680a3f1c686551a7a62c539b7359", null ],
    [ "nr", "struct_t_t_a_r_c_h_i_v_e___h_e_a_d_e_r.html#a298d6246736e810842dbb88846f9b483", null ]
];