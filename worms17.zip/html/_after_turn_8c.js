var _after_turn_8c =
[
    [ "AfterTurn_enter", "_after_turn_8c.html#aab316024849592ea25e9225dabca4ebc", null ],
    [ "AfterTurn_exit", "_after_turn_8c.html#a34bae137b305d977ec5e16dc6bfd48a0", null ],
    [ "AfterTurn_update", "_after_turn_8c.html#a9dc1212cff75bcec45921a462a89da7a", null ],
    [ "waterLevelTimer", "_after_turn_8c.html#ad4e328eadfd858c9d0ea5e593c8dd85e", null ]
];