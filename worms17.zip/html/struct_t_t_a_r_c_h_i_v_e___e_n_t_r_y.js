var struct_t_t_a_r_c_h_i_v_e___e_n_t_r_y =
[
    [ "length", "struct_t_t_a_r_c_h_i_v_e___e_n_t_r_y.html#a92fb67cb6d873cedc8c09a2d901396a2", null ],
    [ "misc1", "struct_t_t_a_r_c_h_i_v_e___e_n_t_r_y.html#accb6a0d47727665cca643823bea73573", null ],
    [ "misc2", "struct_t_t_a_r_c_h_i_v_e___e_n_t_r_y.html#ad00199f3f39e164692aef6992fa43436", null ],
    [ "name", "struct_t_t_a_r_c_h_i_v_e___e_n_t_r_y.html#aaf1bd07e95aeff0f585394fccaf479ab", null ],
    [ "offset", "struct_t_t_a_r_c_h_i_v_e___e_n_t_r_y.html#a33d71f23ba2052d17f0b754dc35265b0", null ]
];