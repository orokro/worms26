var searchData=
[
  ['pausemenuitem',['pauseMenuItem',['../_pause_8c.html#a29368b6b4bdedb20a3924ab3f2a67f10',1,'Pause.c']]],
  ['proxmitychecktimer',['proxmityCheckTimer',['../_mines_8c.html#a03a184e415d586fae62db4391c4ac8de',1,'Mines.c']]]
];
