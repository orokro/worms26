var searchData=
[
  ['gamemodes',['GameModes',['../_main_8h.html#ae1530eae5079db496724a4857d911f09',1,'Main.h']]],
  ['graycolors',['GrayColors',['../extgraph_8h.html#a94e7c587ac22fa5a30a839d203b972d3',1,'extgraph.h']]]
];
