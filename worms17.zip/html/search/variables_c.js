var searchData=
[
  ['userx',['userX',['../_camera_8c.html#a95946c91770bc2514136b411b82531d5',1,'Camera.c']]],
  ['usery',['userY',['../_camera_8c.html#ab515d7a5985dbfa711f189f3106d1738',1,'Camera.c']]]
];
