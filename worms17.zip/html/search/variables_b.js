var searchData=
[
  ['spawnpoint_5fx',['spawnPoint_x',['../_map_8c.html#a93b8ec49f23d77698051c120a9fcbbfa',1,'Map.c']]],
  ['spawnpoint_5fy',['spawnPoint_y',['../_map_8c.html#ab018eb523ce5dc8081a65740a9803a52',1,'Map.c']]]
];
