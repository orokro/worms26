var searchData=
[
  ['minetriggerdistance',['mineTriggerDistance',['../_main_8h.html#a5077aa3342b8b6cb45b3184a8a1227bf',1,'Main.h']]]
];
