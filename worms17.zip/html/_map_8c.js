var _map_8c =
[
    [ "Map_getSpawnPoint", "_map_8c.html#a3b704aa50b57fbd2753c7e00c123653f", null ],
    [ "Map_makeMap", "_map_8c.html#aea81413202c886a64fd8c0eb3dc3fbf5", null ],
    [ "Map_testPoint", "_map_8c.html#a56e1e53157d4c2a502e601a431911d28", null ],
    [ "Map_lastRequestedSpawnX", "_map_8c.html#abbe0a34a5c3bba12da7bff0cf33e3ff0", null ],
    [ "Map_lastRequestedSpawnY", "_map_8c.html#a74807fb34f418ee4c69772f6bc8ec8db", null ],
    [ "spawnPoint_x", "_map_8c.html#a93b8ec49f23d77698051c120a9fcbbfa", null ],
    [ "spawnPoint_y", "_map_8c.html#ab018eb523ce5dc8081a65740a9803a52", null ]
];